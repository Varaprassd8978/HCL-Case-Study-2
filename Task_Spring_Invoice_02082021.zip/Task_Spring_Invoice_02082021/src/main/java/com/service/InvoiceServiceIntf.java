package com.service;

import java.util.List;

import com.model.Invoice;

public interface InvoiceServiceIntf {

	void saveInvoice(Invoice model);

	List<Invoice> getAllInvoices();

	Invoice getInvoiceById(int id);

}
