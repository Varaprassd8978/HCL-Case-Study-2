package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.model.Invoice;
import com.repository.InvoiceRepository;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceServiceIntf {

	@Autowired
	InvoiceRepository repo;

	public void saveInvoice(Invoice model) {
		repo.save(model);
	}

	public List<Invoice> getAllInvoices() {
		return repo.findAll();
	}

	public Invoice getInvoiceById(int id) {

		return repo.findById(id).get();
	}

}
