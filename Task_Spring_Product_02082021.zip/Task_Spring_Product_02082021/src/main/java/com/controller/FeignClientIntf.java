package com.controller;

public interface FeignClientIntf {

}
